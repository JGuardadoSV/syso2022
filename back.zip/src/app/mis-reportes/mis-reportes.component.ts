import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis-reportes',
  templateUrl: './mis-reportes.component.html',
  styleUrls: ['./mis-reportes.component.css']
})
export class MisReportesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
