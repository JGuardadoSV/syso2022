import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-registrar',
  templateUrl: './registrar.component.html',
  styleUrls: ['./registrar.component.css']
})
export class RegistrarComponent implements OnInit {

  formulario!:FormGroup
  usuario={
    correo:'',
    clave:''
  }
  constructor() { }

  ngOnInit(): void {
  }

  registrar(){
    

    console.log(this.usuario)
  }

}
