import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ultimos-reportes',
  templateUrl: './ultimos-reportes.component.html',
  styleUrls: ['./ultimos-reportes.component.css']
})
export class UltimosReportesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
