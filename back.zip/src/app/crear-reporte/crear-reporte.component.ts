import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-reporte',
  templateUrl: './crear-reporte.component.html',
  styleUrls: ['./crear-reporte.component.css']
})
export class CrearReporteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
